#!/bin/bash

while [ 1 ]
do
  echo `date`
  sleep 1
done
