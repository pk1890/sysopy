#!/bin/bash

export LD_LIBRARY_PATH=/home/mleko/sysopy/zestaw1/zadania:$LD_LIBRARY_PATH
./test_shared

